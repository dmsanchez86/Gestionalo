$(document).ready(function(){
    
    $('.button-collapse1').sideNav({
      menuWidth: 500, 
      edge: 'right', 
      closeOnClick: true
    });
    
});

//https://gist.github.com/joakimbeng/7918297/278619bd5ba9b4768eecb0020b09a43f2e8eacea
//http://127.0.0.1:1995/index.html#!
//http://encosia.com/using-external-templates-with-jquery-templates/